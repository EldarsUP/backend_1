from django.shortcuts import render, HttpResponse

# Create your views here.
def info(request):
    return HttpResponse("Батаенков Богдан Владимирович Группа:Бин-22-1 Возраст:23")
def group(request):
    return HttpResponse("Группа:Бин-22-1")
def age(request):
    return HttpResponse("Возраст:23")
def home(request):
    return HttpResponse("/info для всей информации, /age для возраста, /group для группы")