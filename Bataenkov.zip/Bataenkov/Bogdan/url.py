from django.urls import path
from . import views
urlpatterns = [
    path("info/",views.info, name="info"),
    path("group/",views.group, name="group"),
    path("age/",views.age, name="age"),
    path("",views.home, name="home")
]